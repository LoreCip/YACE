#include "NnueNetwork.hpp"
#include <fstream>
#include <algorithm>

bool NnueNetwork::InitializeFromFile(std::string path) {
    std::ifstream file(path, std::ios::binary);
    if (!file.is_open()) return false;

    file.read(reinterpret_cast<char*>(L0Bias), M * sizeof(int16_t));
    file.read(reinterpret_cast<char*>(L0), NUM_FEATURES * M * sizeof(int16_t));
    file.read(reinterpret_cast<char*>(L1Bias), K * sizeof(int32_t));
    file.read(reinterpret_cast<char*>(L1), (2 * M) * K * sizeof(int8_t));
    file.read(reinterpret_cast<char*>(&L2Bias), sizeof(int32_t));    
    file.read(reinterpret_cast<char*>(L2), K * sizeof(int16_t));
    
    char check;
    file.read(&check, 1);
    if (!file.eof()) {
        return false;
    }

    file.close();
    return true;
}

// Attivazione per l'accumulatore (da int16_t a int8_t)
void NnueNetwork::ActivationFunction(const int16_t* in, int8_t* out, int len) {
    for (int i = 0; i < len; i++) {
        // Usiamo QA_BOUND invece del magic number 127
        out[i] = static_cast<int8_t>(std::clamp<int16_t>(in[i], 0, QA_BOUND));
    }
}

// Attivazione per il layer nascosto (da int32_t a int8_t)
void NnueNetwork::ActivationFunction(const int32_t* in, int8_t* out, int len) {
    for (int i = 0; i < len; i++) {
        // Usiamo QA_BOUND
        out[i] = static_cast<int8_t>(std::clamp<int32_t>(in[i], 0, QA_BOUND));
    }
}

void NnueNetwork::DenseLayerLinear(const int8_t* input, const int8_t* weights, const int32_t* bias, int32_t* output, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        int32_t sum = bias[i];
        for (int j = 0; j < cols; j++) {
            sum += input[j] * weights[i * cols + j];
        }
        // De-quantizzazione tramite parametro di shift
        output[i] = sum >> SHIFT_L1; 
    }
}

int32_t NnueNetwork::OutputLayerDotProduct(const int8_t* input, const int16_t* weights, int32_t bias, int len) {
    int32_t dot = bias;
    for (int i = 0; i < len; i++) {
        dot += input[i] * weights[i];
    }
    // De-quantizzazione finale tramite parametro di shift
    return dot >> SHIFT_OUT; 
}

int NnueNetwork::EvaluateNnue(int16_t* smt, int16_t* nsmt) {
    // 1. Attivazione e riempimento buffer di input
    ActivationFunction(smt, inputBuffer, M);
    ActivationFunction(nsmt, inputBuffer + M, M);
    
    // 2. Passaggio nel Layer 1 Nascosto
    int32_t tempHidden[K];
    DenseLayerLinear(inputBuffer, &L1[0][0], L1Bias, tempHidden, K, 2 * M);
    
    // 3. Attivazione del Layer 1
    ActivationFunction(tempHidden, outputBuffer, K);
    
    // 4. Dot Product Finale
    return OutputLayerDotProduct(outputBuffer, L2, L2Bias, K);
}
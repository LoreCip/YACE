#ifndef _LOOKUPTABLES
#define _LOOKUPTABLES

#include <cstdint>

namespace LookupTables{
    extern uint64_t knightAttacks[64];
    extern uint64_t kingAttacks[64];
    extern uint64_t pawnAttacks[2][64];

    // Zobrist Keys
    extern uint64_t pieceKeys[2][6][64];
    extern uint64_t sideKey;

    // Edge bitboard
    inline constexpr uint64_t notColumnA       = 0xFEFEFEFEFEFEFEFE; // 11111110 (Azzera la colonna A)
    inline constexpr uint64_t notColumnH       = 0x7F7F7F7F7F7F7F7F; // 01111111 (Azzera la colonna H)
    inline constexpr uint64_t notColumnADouble = 0xFCFCFCFCFCFCFCFC; // 11111100 (Azzera le colonne A e B)
    inline constexpr uint64_t notColumnHDouble = 0x3F3F3F3F3F3F3F3F; // 00111111 (Azzera le colonne G e H)
    inline constexpr uint64_t nullEdge = 0xFFFFFFFFFFFFFFFF;

    inline constexpr uint64_t thirdRow = 0x0000000000FF0000;
    inline constexpr uint64_t sixthRow = 0x0000FF0000000000;

    void init();
}

#endif
#ifndef _MINIMAX
#define _MINIMAX

#include <vector>

#include "Board.hpp"
#include "Move.hpp"

class Engine {
private:
    int AlphaBeta(Board& board, int depth, int alpha, int beta);
    int QuiescenceSearch(Board& board, int alpha, int beta);
    void GeneratePawnMoves(Board& board, Move* moveList, int& moveCount);

public:
    Move GetBestMove(Board& board, int depth);
    int GenerateAllMoves(Board& board, Move* moveList);

};

#endif